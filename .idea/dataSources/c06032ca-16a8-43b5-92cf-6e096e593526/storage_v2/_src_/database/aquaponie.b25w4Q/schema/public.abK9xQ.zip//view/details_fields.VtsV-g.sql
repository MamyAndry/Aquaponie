create view details_fields
            (id_type_plantation, name_type_plantation, weight_max_baby, weight_max_semi_mature, id_field_plantation,
             id_field, density, surface_covered, plant_weight, insertion_date)
as
SELECT t_p.id_type_plantation,
       t_p.name_type_plantation,
       t_p.weight_max_baby,
       t_p.weight_max_semi_mature,
       f_p.id_field_plantation,
       f_p.id_field,
       f_p.density,
       f_p.surface_covered,
       f_p.plant_weight,
       f_p.insertion_date
FROM field_plantation f_p
         JOIN type_plantation t_p ON f_p.id_type_plantation::text = t_p.id_type_plantation::text;

alter table details_fields
    owner to postgres;

