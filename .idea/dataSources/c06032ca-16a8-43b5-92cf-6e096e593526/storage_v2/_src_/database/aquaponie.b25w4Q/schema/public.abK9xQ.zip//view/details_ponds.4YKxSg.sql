create view details_ponds
            (id_type_fish, name_type_fish, maturity_period, maturity_size, weight_max_little, weight_max_average,
             size_max_little, size_max_average, id_pond_details, id_pond, max_quantity)
as
SELECT t_f.id_type_fish,
       t_f.name_type_fish,
       t_f.maturity_period,
       t_f.maturity_size,
       t_f.weight_max_little,
       t_f.weight_max_average,
       t_f.size_max_little,
       t_f.size_max_average,
       d_p.id_pond_details,
       d_p.id_pond,
       d_p.max_quantity
FROM pond_details d_p
         JOIN type_fish t_f ON d_p.id_type_fish::text = t_f.id_type_fish::text;

alter table details_ponds
    owner to postgres;

